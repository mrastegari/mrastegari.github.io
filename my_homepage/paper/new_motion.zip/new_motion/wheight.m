function w=wheight(V,S)% V=[1*2n]  S=[n*2n]
[m n]=size(S);
n=floor(n/2);
H=S*S';
%x=w';
f=-(S*V');
lb=zeros(n,1)-0;
ub=zeros(n,1)+1;
Aeq=ones(1,m);
beq=1;
[w,fval]=quadprog(H,f,[],[],Aeq,beq,lb,ub);