function [xr,yr]=get_samples_1(x,y,nsamp);
% [xi,yi,ti]=get_samples_1(x,y,t,nsamp);
%
% uses Jitendra's sampling method

N=length(x);
k=3;
Nstart=min(k*nsamp,N);

ind0=randperm(N);
%ind0=1:1:N;
%ind0=ind0(1:Nstart);
xr=x';
yr=y';
xi=x(ind0);
yi=y(ind0);

xi=xi(:);
yi=yi(:);


d2=dist2([xi yi],[xi yi]);
%d2=d2+diag(Inf*ones(Nstart,1));

s=1;
while s
   % find closest pair
   [a,b]=min(d2);
   [c,d]=min(a);
   I=b(d);
   J=d;
   % remove one of the points
   k=[xi(J)+sqrt(-1)*yi(J)];
   xyk=[xr+sqrt(-1)*yr];
   t=find(xyk==k);
   %xt=find(xr==xi(J));
   %yt=find(yr==yi(J));
   xi(J)=[];
   yi(J)=[];
   xr(t)=[];
   yr(t)=[];
   %for i=1:length(xt)
   %    for h=1:length(yt)
   %        if (xt(i)==yt(h))&&(xt(i)~=0)&&(yt(h)~=0) 
   %           xr(xt(i))=[];
   %           yr(xt(i))=[];
   %        end 
   %      end
   %end
   d2(:,J)=[];
   d2(J,:)=[];
   if size(d2,1)==nsamp
      s=0;
   end
end

      