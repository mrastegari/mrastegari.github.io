function re=bnd2fur(bnd)%bnd is 2*n matrix
cbnd=bnd(1,:)+i*bnd(2,:);
fbnd=fft(cbnd);
re=fbnd;