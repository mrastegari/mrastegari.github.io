function re=belong(A,a)
n=length(A);
re=0;
for i=1:n
    if A(i)==a
        re=1;
        break;
    end
end