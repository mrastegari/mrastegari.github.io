function re=rotat(A,t)
n=length(A(1,:));
R=[cos(t),-sin(t);sin(t),cos(t)]
for i=1:n
    B(:,i)=R*A(:,i);
end;
re=B;