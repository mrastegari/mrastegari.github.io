function re=point2im(A,I)
N=length(A(1,:));
[m n]=size(I);
for i=1:N
    if (round(A(1,i))<m) &&(round(A(2,i))<n)&&(round(A(1,i))>0) &&(round(A(2,i))>0)
        I(round(A(1,i)),round(A(2,i)))=0;
    end
end;
I=double(I);
I=imcomplement(I);
re=I;
