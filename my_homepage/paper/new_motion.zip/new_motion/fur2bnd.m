function re=fur2bnd(fur)%fur is 1*n matrix
cbnd=ifft(fur);
bnd(1,:)=real(cbnd);
bnd(2,:)=imag(cbnd);
re=bnd;