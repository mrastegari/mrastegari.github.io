function re=affine_perm3(bnd1,bnd2);
prp1=proper(bnd1);
prp2=proper(bnd2);
bndt1=bnd1;
bndt2=bnd2;
bndt1(3,:)=1;
bndt2(3,:)=1;


O1x=prp1(1,2); O1y=prp1(2,2); m1=prp1(1,1);
O2x=prp2(1,2); O2y=prp2(2,2); m2=prp2(1,1);
To1=[1 0 -O1x;0 1 -O1y];
To2=[1 0 -O2x;0 1 -O2y;0 0 1];
bndt1=To1*bndt1;
bndt2=To2*bndt2;

max1=max([max(abs(bndt1(1,:))) max(abs(bndt1(2,:)))]);
max2=max([max(abs(bndt2(1,:))) max(abs(bndt2(2,:)))]);

t1=atan(m1);
t2=atan(m2);
if t1<0
    t1=pi+t1;
end
if t2<0
    t2=pi+t2;
end
t=t1-t2+pi;
dx=O1x/max1-O2x/max2;
dy=O1y/max1-O2y/max2;
M2=[1/max2 0 0;0 1/max2 0;0 0 1];
M1=[max1 0 0;0 max1 0;0 0 1];
T=[1 0 dx-O1x/max1;0 1 dy-O1y/max1;0 0 1];
R=[cos(t) -sin(t) 0;sin(t) cos(t) 0;0 0 1];
aff=-To1*M1*R*M2*To2;
%aff=M1*R*T*M2;

bnd2(3,:)=1;
affbnd2=aff*bnd2;

result=struct('affperm',{},'affcor',{});
    result(1).affperm=affbnd2;
    result(1).affcor=aff;
    re=result;
