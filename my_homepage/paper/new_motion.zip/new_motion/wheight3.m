function w=wheight(V,S)% V=[1*2n]  S=[n*2n]
[m n]=size(S);
%n=floor(n/2);
H=S'*S;
%x=w';
f=-(S*V');
lb=zeros(n,1);
ub=zeros(n,1)+1;
Aeq=zeros(n+1,n);
Aeq(1,1:n)=1;
for i=1:floor(n/2) 
   Aeq(i+1,i)=1;
   Aeq(i+1,i+floor(n/2))=-1;
end
beq=zeros(n+1,1);
beq(1,1)=1;
[w,fval]=quadprog(H,f,[],[],Aeq,beq,lb,ub);
%w=w(1:floor(n/2));