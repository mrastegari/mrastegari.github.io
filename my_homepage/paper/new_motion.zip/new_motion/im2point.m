function re=im2point(I)%I must be binary image
[x,y]=size(I);
c=0;
for i=1:x
    for j=1:y
        if I(i,j)<1
            c=c+1;
            A(1,c)=i;
            A(2,c)=j;
        end
    end
end
re=A;
        