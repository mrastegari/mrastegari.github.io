function re=proper(bnd)
long=longest_pair(bnd);
x1=bnd(1,long(1));y1=bnd(2,long(1));
x2=bnd(1,long(2));y2=bnd(2,long(2));
m=(y2-y1)/(x2-x1);
b1=min(-m*bnd(1,:)+bnd(2,:));
b2=max(-m*bnd(1,:)+bnd(2,:));
M=-(m+1/m);
x_1=(b1-((x1/m)+y1))/M; y_1=m*x_1+b1;
x_2=(b2-((x1/m)+y1))/M; y_2=m*x_2+b2;
x_3=(b1-((x2/m)+y2))/M; y_3=m*x_3+b1;
x_4=(b2-((x2/m)+y2))/M; y_4=m*x_4+b2;
O=[(x_1+x_2+x_3+x_4)/4;(y_1+y_2+y_3+y_4)/4;];
re=[m O(1);0 O(2)];