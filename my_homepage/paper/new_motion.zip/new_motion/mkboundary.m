function re=mkboundary(I)%I must be a gray scale image
I=im2bw(I,0.8);
[m n]=size(I);
Icomp=imcomplement(I);
Icomp=bwmorph(Icomp,'close');

flag=0;
for j=1:n
    for i=1:m
        if Icomp(i,j)==1
            flag=1;
            break;
        end
    end
    if flag==1
       break;
    end
end   
start_point=[i j];
contour = bwtraceboundary(Icomp, [i, j], 'N');
re=contour;   