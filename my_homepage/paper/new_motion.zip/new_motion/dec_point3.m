function A2=dec_point3(A,m)
n=length(A);
h=n-m;
x=1:1:h;
y=((n-1)/(h-1))*(x-1)+1;
A(:,round(y))=[];
A2=A;