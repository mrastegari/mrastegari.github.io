function i_min=longest_pair(A)
n=length(A);
min=0;
for i=1:n-1
    for j=i+1:n
        if i~=j
            d=abs(sqrt((A(1,i)-A(1,j))^2+(A(2,i)-A(2,j))^2));
            if d>min 
                min=d;
                i1_min=i;
                i2_min=j;
                
            end
        end
    end
end
i_min=[i1_min i2_min];