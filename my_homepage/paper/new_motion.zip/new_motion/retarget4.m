%%%This function compute a target-shape from source-shape by some key-shape
%%%as input(source key-shapes) and others as output(target key-shapes)
%%%sourceshape: is the path of the source shpe's image
%%%inkeyshape: is a struct which contain the path of all source key-shapes
%%%outkeyshape:is a struct which contain the path of all target key-shapes
%%% the out put of this function is a boundary of target shape which is an array 2*N.
%%%sample runing:
%%% >>sourceshape='c:\shape\sc_shape.bmp';
%%%>>inkeyshape(1).img='c:\shape\sc_key_shape1.bmp';
%%%>>inkeyshape(2).img='c:\shape\sc_key_shape2.bmp';
%%%>>inkeyshape(3).img='c:\shape\sc_key_shape3.bmp';
%%%>>outkeyshape(1).img='c:\shape\tg_key_shape1.bmp';
%%%>>outkeyshape(2).img='c:\shape\tg_key_shape2.bmp';
%%%>>outkeyshape(3).img='c:\shape\tg_key_shape3.bmp';
%%%>>retarget4(sourceshape,inkeyshape,outkeyshape)

function Vout=retarget4(sourceshape,inkeyshapes,outkeyshapes)%inkeyshapes,outkeyshapes=struct('img',{})
nmin=Inf;
Sshape=imread(sourceshape);
Sshape=rgb2gray(Sshape);
boundSshape=mkboundary(Sshape)';%%%%%make boundary as 2*n array
%%%secttion 1 : in this section we want to find the shape which have minimum size in the
%%%number of pixel
[m n]=size(boundSshape);
    if n<nmin
        nmin=n;
    end

inkeybound=struct('bnd',{});

for i=1:length(inkeyshapes)
    inkeybound(i).bnd=mkboundary(rgb2gray(imread(inkeyshapes(i).img)))';
    [m n]=size(inkeybound(i).bnd);
    if n<nmin
        nmin=n;
    end
end
outkeybound=struct('bnd',{});
for i=1:length(outkeyshapes)
    outkeybound(i).bnd=mkboundary(rgb2gray(imread(outkeyshapes(i).img)))';
    [m n]=size(outkeybound(i).bnd);
    if n<nmin
        nmin=n;
    end
end
nmin=nmin;
%%%% end of section 1
%% section2: in this sectin we decrease the number of pixels of all shapes to the minimum. 
boundSshape=dec_point3(boundSshape,nmin);


for i=1:length(outkeyshapes)
    outkeybound(i).bnd=dec_point3(outkeybound(i).bnd,nmin);
    inkeybound(i).bnd=dec_point3(inkeybound(i).bnd,nmin);
end

%% end of section 2
%% section 3 : in this section we want to find the affine coefficients and
%% affine permutation

for i=1:length(outkeyshapes)
   
    inkeyboundaff(i).bnd=affine_perm3(boundSshape,inkeybound(i).bnd);
end

%%end of section 3

%%section 4: in this section we compute the Fourier Decriptor for each shapes and
%%compue the weights for Key-shape Deformation 
fiV=bnd2fur(boundSshape);
fV=[real(fiV) imag(fiV)];

S=zeros(length(inkeyshapes),length(fV));
for i=1:length(inkeyshapes)
    S(i,:)=[real(bnd2fur(inkeyboundaff(i).bnd(1).affperm)) imag(bnd2fur(inkeyboundaff(i).bnd(1).affperm))];
end
W=wheight(fV,S);
%% end of section 4
%%section 5: in this section we make the target shape by operating the
%%affine and non-affaine coefficient on target key-shapes
fVout=0;
for i=1:length(outkeyshapes)
    outkeybound(i).bnd(3,:)=1;
    outkeybound(i).bnd=inkeyboundaff(i).bnd(1).affcor*outkeybound(i).bnd;
    fVout=fVout+W(i)*bnd2fur(outkeybound(i).bnd);
    Vout=fur2bnd(fVout);
end
plot(Vout(1,:),Vout(2,:));
%%end of section 5.
