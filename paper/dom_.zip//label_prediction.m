function predicted_label=label_prediction(classifiers, data);
[m n]=size(data);
 %% Accuracy L2-svm %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            confidence= (classifiers'*[data; ones(1,n)]);
            stdr=repmat(std(confidence,[],2),1,n);
            meanr=repmat(mean(confidence,2),1,n);
            confidence=(confidence-meanr)./stdr;
             [max_conf predicted_label]=max(confidence);
