function [Out, source_dbc,target_dbc]=DA_Kmeans(source_domain,target_domain,K)

addpath(genpath('./'));
addpath(genpath('../util'));

%%% construct train_data
load([source_domain]);
source_data=fts';
source_labels=labels;
%source_labels(source_labels~=1)=2; uncomment for binary classification

%train_imgName=imgNames;

%%% construct test_data
load([target_domain])
target_data=fts';
target_labels=labels;
%target_labels(target_labels~=1)=2;
%train_imgName=imgNames;


%%% feature pre-processing
train_data=vl_homkermap(normalization(source_data),1);
test_data=vl_homkermap(normalization(target_data),1);





%%% discover attribute classifiers in target domains 
classifiers=one_vs_all(train_data,source_labels,10);
estimated_label=label_prediction(classifiers,test_data);
 no_adapt_acc=Categorization_rate(classifiers, test_data, target_labels)

 
for iter=1:1 
    
% %%% apply K-means on target domain
if K>1
    uLabel=unique(target_labels);
    nCats= length(uLabel);
    cl_label=[];
    for i=1:nCats
        indx=estimated_label==uLabel(i);
        [C, tmp_label]=vl_kmeans(target_data(:,indx),K);
        cl_label(indx)=(i-1)*K+double(tmp_label);
    end
else
    cl_label=estimated_label;
end

dbc_model=DBC_train(test_data,cl_label,256,'-B 1 -c 1 -s 1');

%%% apply attribute classifier in source domain and target domain
source_dbc=DBC_apply(train_data,dbc_model)>0;
target_dbc=DBC_apply(test_data,dbc_model)>0;

%%%  learn one-vs-all SVM  on attribute space in source domain
classifiers=one_vs_all(source_dbc,source_labels,1);
estimated_label=label_prediction(classifiers,target_dbc);

end
%%% test SVMs on attribute space in target domain
 acc=Categorization_rate(classifiers, target_dbc, target_labels);

%%% report accuracy

Out=acc