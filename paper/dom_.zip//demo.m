%% You need to have Liblinear and vl_feat library installed

addpath(genpath('./'));
[acc, source_dbc,target_dbc]=DA_Kmeans('Caltech10_SURF_L10','amazon_SURF_L10.mat',1);