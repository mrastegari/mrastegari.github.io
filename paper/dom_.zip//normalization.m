function B=normalization(A)
[m n]=size(A);
B=A./repmat(sqrt(sum(A.^2)),m,1);