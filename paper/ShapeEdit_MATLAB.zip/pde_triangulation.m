function [tri,allpoints,inpoints]=pde_triangulation(bound,initsize,refinenum,refinerate);
d1=mypoly(bound(:,1)',bound(:,2)');
if (initsize=='estimate') [p e t]=initmesh(d1,'Hgrad',refinerate);
else 
    [p e t]=initmesh(d1,'Hmax',initsize,'Hgrad',refinerate);
end
for i=1:refinenum
    [p e t]=refinemesh(d1,p,e,t);
    p=jigglemesh(p,e,t,'Iter',10);
end
TRI=t(1:3,:)';
n=length(bound(:,1));


%triplot(TRI,p(1,:),p(2,:))
tri=TRI;
allpoints=p';
inpoints=t(1:3,length(bound(:,1))+1:length(t(1,:)))';
%figure(2);
%plot(p(1,1:length(bound(:,1)),1),p(2,1:length(bound(:,1))));
%hold on;
%plot(bound(:,1),bound(:,2),'red');
