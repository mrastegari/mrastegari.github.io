function model=shape_edit_registering(bnd);

max_X=max(bnd(:,1));
max_Y=max(bnd(:,2));
min_X=min(bnd(:,1));
min_Y=min(bnd(:,2));
mm=max_X-min_X;
nn=max_Y-min_Y;
shape_center=[round((max_X+min_X)/2) round((max_Y+min_Y)/2)];
im=zeros(mm+100,nn+100);
im_center=[(mm+100)/2 (nn+100)/2];
delta_center=im_center-shape_center;
bnd(:,1)=bnd(:,1)+delta_center(1);
bnd(:,2)=bnd(:,2)+delta_center(2);
[tri,p,inpoints]=pde_triangulation(bnd,5000,0,2-eps);
p=round(p);
top=length(p(:,1));
imshow(im);
hold on;
triplot(tri,p(:,2),p(:,1),'red');
hold off;

%%===============Registration======================================
m=length(tri(:,1));
G=zeros(2*top,2*top);
for k=1:m   
    
    for l=1:3
        r=tri(k,l); s=tri(k,mod(l,3)+1); z=tri(k,mod(l+1,3)+1);
        x01=((p(s,:)-p(r,:))*(p(z,:)-p(r,:))')/((p(s,:)-p(r,:))*(p(s,:)-p(r,:))');%abs??
        y01=(cross2((p(s,:)-p(r,:)),(p(z,:)-p(r,:))))/((p(s,:)-p(r,:))*(p(s,:)-p(r,:))');
        %H=zeros(2*top,2);
        %x01=-x01; y01=-y01;


        H(1,1)=1-x01; H(1,2)=y01;
        H(2,1)=-y01; H(2,2)=1-x01;
        
        H(3,1)=x01; H(3,2)=-y01;
        H(4,1)=y01; H(4,2)=x01;
        
        H(5,1)=-1; H(5,2)=0;
        H(6,1)=0; H(6,2)=-1;
       
        T=[2*r-1 2*r 2*s-1 2*s 2*z-1 2*z];
        for i=1:6
            for j=1:6
                G(T(i),T(j))=G(T(i),T(j))+H(i,1)*H(j,1)+H(i,2)*H(j,2);
            end
        end
        
        
    end    
end

p0=p;


%%%===== stageIII=====================================
G2=zeros(2*top,2*top);


for k=1:m
    for l=1:3
        r=tri(k,l); s=tri(k,mod(l,3)+1); z=tri(k,mod(l+1,3)+1);
        %H2=zeros(2*top,2);
        H2(1,1)=-1; H2(1,2)=0;
        H2(2,1)=0; H2(2,2)=-1;
        H2(3,1)=1; H2(3,2)=0;
        H2(4,1)=0; H2(4,2)=1;
        T=[2*r-1, 2*r, 2*s-1, 2*s];
        for i=1:4
            for j=1:4
                G2(T(i),T(j))=G2(T(i),T(j))+H2(i,1)*H2(j,1)+H2(i,2)*H2(j,2);
            end
        end
 
    end
end
%__________________________________________
%%===============================================================
cnt=0;
t=0;
while t~=3
    [j i t]=ginput(1);
    i=i;
    j=j;
    near=[];
    min=Inf;
    for k=1:top
        if (abs(i-p(k,1))<=5)&(abs(j-p(k,2))<=5)
           dist=norm([i j]-[p(k,1) p(k,2)]);
           if dist<min
               min=dist;
               near=k;
           end;
       end   
   end   
       if ~isempty(near)   
           cnt=cnt+1;
           constant_point(cnt)=near;
           c=p(near,1);
           d=p(near,2);
           im(c-2:c+2,d-2:d+2)=255*ones(5);
           imshow(im);
           hold on;
           triplot(tri,p(:,2),p(:,1),'red');
           hold off;
       end
           
       
end






%t=0;
%while t~=3
%    [j i t]=ginput(1);
%    for k=1:top
%        if (abs(i-p(k,1))<=5)&(abs(j-p(k,2))<=5)
%           cnt=cnt+1;
%           constant_point(cnt)=k;
%           c=p(k,1)
%           d=p(k,2)
%           im(c-2:c+2,d-2:d+2)=255*ones(5);
%           imshow(im);
%           hold on;
%           triplot(tri,p(:,2),p(:,1),'red');
%           hold off;
%           
%       end
%   end
%end

%--------------------------------------------
%%============Compilation=========================================
% reordering_________________________________
sigma=1:top;
for i=1:cnt        
    index1=2*constant_point(i)-1;
    index2=2*top-2*cnt+2*i-1;
    
    temp=G(:,index1); G(:,index1)=G(:,index2); G(:,index2)=temp;
    temp=G(index1,:); G(index1,:)=G(index2,:); G(index2,:)=temp;
    
    index1=index1+1; index2=index2+1;
    temp=G(:,index1); G(:,index1)=G(:,index2); G(:,index2)=temp;
    temp=G(index1,:); G(index1,:)=G(index2,:); G(index2,:)=temp;
    sigma(index1/2)=index2/2; sigma(index2/2)=index1/2;
end      
G00=G(1:2*top-2*cnt,1:2*top-2*cnt);
G01=G(1:2*top-2*cnt,2*top-2*cnt+1:2*top);
G10=G(2*top-2*cnt+1:2*top,1:2*top-2*cnt);
G11=G(2*top-2*cnt+1:2*top,2*top-2*cnt+1:2*top);

A=G00+G00'; B=G01+G10';
B_inv_A=B'*inv(A);


sigma2=1:top;
for i=1:cnt        
    index1=2*constant_point(i)-1;
    index2=2*top-2*cnt+2*i-1;
    
    temp=G2(:,index1); G2(:,index1)=G2(:,index2); G2(:,index2)=temp;
    temp=G2(index1,:); G2(index1,:)=G2(index2,:); G2(index2,:)=temp;
    
    
    index1=index1+1; index2=index2+1;
    temp=G2(:,index1); G2(:,index1)=G2(:,index2); G2(:,index2)=temp;
    temp=G2(index1,:); G2(index1,:)=G2(index2,:); G2(index2,:)=temp;
    
    
    sigma2(index1/2)=index2/2; sigma2(index2/2)=index1/2;
end      



% making the submatrixes______________________
G200=G2(1:2*top-2*cnt,1:2*top-2*cnt);
G201=G2(1:2*top-2*cnt,2*top-2*cnt+1:2*top);
G210=G2(2*top-2*cnt+1:2*top,1:2*top-2*cnt);
G211=G2(2*top-2*cnt+1:2*top,2*top-2*cnt+1:2*top);

A2=G200+G200'; B2=G201+G210';
inv_A2=inv(A2);
inv_A2_B2=(inv_A2*(-B2));

%%=======================================================================
p(:,1)=p(:,1)-delta_center(1);
p(:,2)=p(:,2)-delta_center(2);

model{1}=constant_point;
model{2}=p;
model{3}=cnt;
model{4}=B_inv_A;
model{5}=top;
model{6}=sigma;
model{7}=mm;
model{8}=nn;
model{9}=tri;
model{10}=p0;
model{11}=inv_A2_B2;
model{12}=inv_A2;
model{13}=sigma2;
model{14}=delta_center;