function re=mypoly(x,y,label)
%PDEPOLY Draw polygon, update Geometry Description matrix.
%
%       PDEPOLY(X,Y,LABEL) adds a polygon with vertices
%       determined by vectors X and Y and a label (name) LABEL.
%       Label is optional. A label will be assigned automatically
%       if omitted.
%
%       See also: PDECIRC PDEELLIP PDERECT

%       Magnus Ringh 9-21-94, MR 7-20-95.
%       Copyright 1994-2001 The MathWorks, Inc.
%       $Revision: 1.8 $  $Date: 2001/02/09 17:03:18 $

n=length(x);

if nargin<2
  error('Too few input arguments')
end

if ~(any(size(x)==1) & any(size(y)==1))
  error('Input data must be vectors')
end

if ~(isreal(x) & isreal(y))
  error('Input data must be real')
end

n=length(x);

if length(y)~=n,
  error('Input data dimensions are inconsistent')
end

if nargin>2
  if ~isstr(label)
    error('Label must be a string')
  end
end

%pde_fig=findobj(allchild(0),'flat','Tag','PDETool');
% If PDETOOL not started, create PDETOOL interface

pde_poly=2;

%h=findobj(allchild(pde_fig),'flat','Tag','PDEMeshMenu');
%pdegd=get(h,'UserData');
pdegd=[];
% update PDEGD matrix
m=1;
pdegd(1,m)=pde_poly;
pdegd(2,m)=n;
pdegd(3:2+n,m)=x';
pdegd(3+n:2*n+2,m)=y';



% First call DECSG to decompose geometry;

re=decsg(pdegd);