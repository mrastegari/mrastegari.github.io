As-Rigid-As Possible Shape Manipulation 1 README.


This package contains the Rigid Deformation method for shape manipulation.

It may be useful to see the paper below to know the theory and application of each function.

[1] Takeo Igarashi, Tomer Moscovich, John F. Hughes, "As-Rigid-As-Possible Shape Manipulation",ACM Transactions on Computer Graphics, Vol.24, No.3, ACM SIGGRAPH 2005, Los Angels, USA, 2005.

[2] Cartoon Motion Capturing and Retargeting by Rigid Shape Manipulation. M. Rastegari, M. Rouhani, N. Gheissari, and M.M. Pedram. IEEE proceeding, Digital Image Computing Technique and Application (DICTA) 2009, 

Written in MATLAB 
By: Mohmmad Rastegari

USAGE:
    You can just run these functions with the following order:
        >>load test.mat
        >>shape_edit(bnd)

Then you will see a triangulated plot of the shape. You must select the key-points by left-click on the point on a triangle (NOTE: select the last key-point by right-click). Then click (left-click) on a selected key-point and then to change its location click (left-click) on a place inside the plot. You will see the  two steps of rigid deformation. 
You can also use your extracted boundary (shape) instead of "bnd". It must be a N-by-2 double array of the sample points coordinates (X,Y) of . N is the number of sample points.   