function shape_edit(bnd);

mm=max(bnd(:,1));
nn=max(bnd(:,2));
im=zeros(mm+100,nn+100);
bnd(:,1)=bnd(:,1)+50;
bnd(:,2)=bnd(:,2)+50;
[tri,p,inpoints]=pde_triangulation(bnd,5000,0,2-eps);
p=round(p);
top=length(p(:,1));
imshow(im);
hold on;
triplot(tri,p(:,2),p(:,1),'red');
hold off;

%%===============Registration======================================
m=length(tri(:,1));
G=zeros(2*top,2*top);
for k=1:m   
    
    for l=1:3
        r=tri(k,l); s=tri(k,mod(l,3)+1); z=tri(k,mod(l+1,3)+1);
        x01=((p(s,:)-p(r,:))*(p(z,:)-p(r,:))')/((p(s,:)-p(r,:))*(p(s,:)-p(r,:))');%abs??
        y01=(cross2((p(s,:)-p(r,:)),(p(z,:)-p(r,:))))/((p(s,:)-p(r,:))*(p(s,:)-p(r,:))');
        %H=zeros(2*top,2);
        %x01=-x01; y01=-y01;


        H(1,1)=1-x01; H(1,2)=y01;
        H(2,1)=-y01; H(2,2)=1-x01;
        
        H(3,1)=x01; H(3,2)=-y01;
        H(4,1)=y01; H(4,2)=x01;
        
        H(5,1)=-1; H(5,2)=0;
        H(6,1)=0; H(6,2)=-1;
       
        T=[2*r-1 2*r 2*s-1 2*s 2*z-1 2*z];
        for i=1:6
            for j=1:6
                G(T(i),T(j))=G(T(i),T(j))+H(i,1)*H(j,1)+H(i,2)*H(j,2);
            end
        end
        
        
    end    
end

p0=p;


%%%===== stageIII=====================================
G2=zeros(2*top,2*top);


for k=1:m
    for l=1:3
        r=tri(k,l); s=tri(k,mod(l,3)+1); z=tri(k,mod(l+1,3)+1);
        %H2=zeros(2*top,2);
        H2(1,1)=-1; H2(1,2)=0;
        H2(2,1)=0; H2(2,2)=-1;
        H2(3,1)=1; H2(3,2)=0;
        H2(4,1)=0; H2(4,2)=1;
        T=[2*r-1, 2*r, 2*s-1, 2*s];
        for i=1:4
            for j=1:4
                G2(T(i),T(j))=G2(T(i),T(j))+H2(i,1)*H2(j,1)+H2(i,2)*H2(j,2);
            end
        end
 
    end
end
%__________________________________________
%%===============================================================
cnt=0;
t=0;
while t~=3
    [j i t]=ginput(1);
    near=[];
    min=Inf;
    for k=1:top
        if (abs(i-p(k,1))<=5)&(abs(j-p(k,2))<=5)
           dist=norm([i j]-[p(k,1) p(k,2)]);
           if dist<min
               min=dist;
               near=k;
           end;
       end   
   end   
       if ~isempty(near)   
           cnt=cnt+1;
           constant_point(cnt)=near;
           c=p(near,1);
           d=p(near,2);
           im(c-2:c+2,d-2:d+2)=255*ones(5);
           imshow(im);
           hold on;
           triplot(tri,p(:,2),p(:,1),'red');
           hold off;
       end
           
       
end






%t=0;
%while t~=3
%    [j i t]=ginput(1);
%    for k=1:top
%        if (abs(i-p(k,1))<=5)&(abs(j-p(k,2))<=5)
%           cnt=cnt+1;
%           constant_point(cnt)=k;
%           c=p(k,1)
%           d=p(k,2)
%           im(c-2:c+2,d-2:d+2)=255*ones(5);
%           imshow(im);
%           hold on;
%           triplot(tri,p(:,2),p(:,1),'red');
%           hold off;
%           
%       end
%   end
%end

%--------------------------------------------
%%============Compilation=========================================
% reordering_________________________________
sigma=1:top;
for i=1:cnt        
    index1=2*constant_point(i)-1;
    index2=2*top-2*cnt+2*i-1;
    
    temp=G(:,index1); G(:,index1)=G(:,index2); G(:,index2)=temp;
    temp=G(index1,:); G(index1,:)=G(index2,:); G(index2,:)=temp;
    
    index1=index1+1; index2=index2+1;
    temp=G(:,index1); G(:,index1)=G(:,index2); G(:,index2)=temp;
    temp=G(index1,:); G(index1,:)=G(index2,:); G(index2,:)=temp;
    sigma(index1/2)=index2/2; sigma(index2/2)=index1/2;
end      
G00=G(1:2*top-2*cnt,1:2*top-2*cnt);
G01=G(1:2*top-2*cnt,2*top-2*cnt+1:2*top);
G10=G(2*top-2*cnt+1:2*top,1:2*top-2*cnt);
G11=G(2*top-2*cnt+1:2*top,2*top-2*cnt+1:2*top);

A=G00+G00'; B=G01+G10';
B_inv_A=B'*inv(A);


sigma2=1:top;
for i=1:cnt        
    index1=2*constant_point(i)-1;
    index2=2*top-2*cnt+2*i-1;
    
    temp=G2(:,index1); G2(:,index1)=G2(:,index2); G2(:,index2)=temp;
    temp=G2(index1,:); G2(index1,:)=G2(index2,:); G2(index2,:)=temp;
    
    
    index1=index1+1; index2=index2+1;
    temp=G2(:,index1); G2(:,index1)=G2(:,index2); G2(:,index2)=temp;
    temp=G2(index1,:); G2(index1,:)=G2(index2,:); G2(index2,:)=temp;
    
    
    sigma2(index1/2)=index2/2; sigma2(index2/2)=index1/2;
end      



% making the submatrixes______________________
G200=G2(1:2*top-2*cnt,1:2*top-2*cnt);
G201=G2(1:2*top-2*cnt,2*top-2*cnt+1:2*top);
G210=G2(2*top-2*cnt+1:2*top,1:2*top-2*cnt);
G211=G2(2*top-2*cnt+1:2*top,2*top-2*cnt+1:2*top);

A2=G200+G200'; B2=G201+G210';
inv_A2=inv(A2);
inv_A2_B2=(inv_A2*(-B2));

%%=======================================================================

while (1)
%moving some constraint points:
[j i t]=ginput(1);
if t==3
    break;
end
for r=1:cnt
    k=constant_point(r);
    if (abs(i-p(k,1))<=5)&(abs(j-p(k,2))<=5)
        index=k;
        
    end
end
[j i t]=ginput(1);

p(index,1)=round(i); p(index,2)=round(j);


% making the submatrixes______________________

for i=1:cnt
    k=constant_point(i);
    q(2*i-1)=p(k,1);
    q(2*i)=p(k,2);
end

u=-q*B_inv_A;%*(B*q');
% update the cordinates____________________
newp=zeros(top,2);
for i=1:cnt
    k=constant_point(i);
    newp(k,1)=q(2*i-1);
    newp(k,2)=q(2*i);
end
index=0;
for i=1:top
    if ~newp(sigma(i),1)
         index=index+1;
         newp(sigma(i),1)=u(2*index-1);
         newp(sigma(i),2)=u(2*index);
    end
end
% refresh the screen:_____________________
figure(2);
im=zeros(mm+100,nn+100);



for r=1:cnt
    k=constant_point(r);
    c=newp(k,1);
    d=newp(k,2);
    im(c-2:c+2,d-2:d+2)=255*ones(5);
end
imshow(im);
hold on;
triplot(tri,newp(:,2),newp(:,1),'red');
hold off;
%_________________________________________
%____Stage II_____________________________
for k=1:m
    r=tri(k,1);    s=tri(k,2);    z=tri(k,3);
    v=[p0(r,1), p0(r,2), p0(s,1), p0(s,2), p0(z,1), p0(z,2)];
    u=[newp(r,1), newp(r,2), newp(s,1), newp(s,2), newp(z,1), newp(z,2)];
    %AA=[p(r,1) p(r,2); p(s,1) p(s,2)];
    %BB=[newp(r,1) newp(r,2) ; newp(s,1) newp(s,2)];
    %=======================my work===================
  T1=[v(1) v(2); v(3) v(4); v(5) v(6)];
  T2=[u(1) u(2); u(3) u(4); u(5) u(6)];
  M1=[sum(T1(:,1)) sum(T1(:,2))]/3;
  M2=[sum(T2(:,1)) sum(T2(:,2))]/3;
  TM1=T1([1 2 3],:)-[M1;M1;M1];
  TM2=T2([1 2 3],:)-[M2;M2;M2];
  aff=TM2'*pinv(TM1');
   [Ra D Rb]=svd(aff);
    R=Ra*Rb';
    %tet1=abs(acos(R(1,1))); tet2=abs(asin(R(1,2))); tet3=abs(asin(-R(2,1))); tet4=abs(acos(R(2,2)));
    %tet=(tet1+tet2+tet3+tet4)/4;
    %R=[cos(tet) -sin(tet);sin(tet) cos(tet)];
    TM1fitted=(R*TM1')';
   
    T1fitted=TM1fitted([1 2 3],:)+[M2;M2;M2];
    w=[];
    w(1)=T1fitted(1,1); w(2)=T1fitted(1,2);
    w(3)=T1fitted(2,1); w(4)=T1fitted(2,2);
    w(5)=T1fitted(3,1); w(6)=T1fitted(3,2);
  
  

    % Emin=Inf;
  % Wmin=[];
  % for i=1:3
  %  T1=[v(1) v(2); v(3) v(4); v(5) v(6)];
  % T1(:,1)=circshift(T1(:,1),i);
  % T1(:,2)=circshift(T1(:,2),i);
   %  T2=[u(1) u(2); u(3) u(4); u(5) u(6)];
   % M1=[sum(T1(:,1)) sum(T1(:,2))]/3;
   % M2=[sum(T2(:,1)) sum(T2(:,2))]/3;
   % TM1=T1([1 2 3],:)-[M1;M1;M1];
   % TM2=T2([1 2 3],:)-[M2;M2;M2];
   % %%===TM2'=aff*TM1'
   % aff=TM2'*pinv(TM1');
   % [Ra D Rb]=svd(aff);
   % R=Ra*Rb;
   % tet1=acos(R(1,1)); tet2=asin(R(1,2)); tet3=asin(-R(2,1)); tet4=acos(R(2,2));
   % tet=(tet1+tet2+tet3+tet4)/4;
   % R=[cos(tet) sin(tet);-sin(tet) cos(tet)];
   % TM1fitted=(R*TM1')';
   % E=norm(TM1fitted-TM2);
   % T1fitted=TM1fitted([1 2 3],:)+[M2;M2;M2];
   % w=[];
   % w(1)=T1fitted(1,1); w(2)=T1fitted(1,2);
   % w(3)=T1fitted(2,1); w(4)=T1fitted(2,2);
   % w(5)=T1fitted(3,1); w(6)=T1fitted(3,2);
   % if E<Emin 
   %     Emin=E;
   %     Wmin=w;
   % end
   %end
  %w=Wmin;
    %%=====================end my work==========
    
  %  scale=sqrt((v(1)-v(3))^2+(v(2)-v(4))^2)/sqrt((u(1)-u(3))^2+(u(2)-u(4))^2);%norm(AA)/norm(BB);
  %  M=[newp(r,1)+newp(s,1)+newp(z,1) newp(r,2)+newp(s,2)+newp(z,2)]/3;
  %  U=zeros(1,6);
    %w=stageII(v,u);
  %  U([1 3 5])=u([1 3 5])-M(1);
  %  U([2 4 6])=u([2 4 6])-M(2);
  %  U=U*scale;
  %  w([1 3 5])=U([1 3 5])+M(1);
  %  w([2 4 6])=U([2 4 6])+M(2);
    
    
    
    
    newtri(k,1)=3*k-2;   newtri(k,2)=3*k-1;    newtri(k,3)= 3*k;
    newpp(3*k-2,1)=w(1);newpp(3*k-2,2)=w(2);
    newpp(3*k-1,1)=w(3);newpp(3*k-1,2)=w(4);
   newpp(3*k,1)=w(5);newpp(3*k,2)=w(6);
end
%how to save these w.s??   ...ok!
% refresh the screen:_____________________
figure(3);
im=zeros(mm+100,nn+100);
for r=1:cnt
    k=constant_point(r);
    c=newp(k,1);
    d=newp(k,2);
    im(c-2:c+2,d-2:d+2)=255*ones(5);
end
imshow(im);
hold on;
triplot(newtri,newpp(:,2),newpp(:,1),'blue');
triplot(tri,newp(:,2),newp(:,1),'red');
hold off;



%_________________________________________
%____Stage III_____________________________
%%%===== stageIII=====================================

f=zeros(2*top,1); %?

for k=1:m
    for l=1:3
        r=tri(k,l); s=tri(k,mod(l,3)+1); z=tri(k,mod(l+1,3)+1);
        
        ww=[newpp(3*k-2+mod(l,3),1)-newpp(3*k-3+l,1) ; newpp(3*k-2+mod(l,3),2)-newpp(3*k-3+l,2)];
        f(2*r-1)=f(2*r-1)+2*ww(1); f(2*r)=f(2*r)+2*ww(2);
        f(2*s-1)=f(2*s-1)-2*ww(1); f(2*s)=f(2*s)-2*ww(2);
    end
end
%__________________________________________

for i=1:cnt        
    index1=2*constant_point(i)-1;
    index2=2*top-2*cnt+2*i-1;
    
    
    temp=f(index1); f(index1)=f(index2); f(index2)=temp;
    
    index1=index1+1; index2=index2+1;
    
    temp=f(index1); f(index1)=f(index2); f(index2)=temp;
    
    
end      



% making the submatrixes______________________

f0=f(1:2*top-2*cnt);
 %C=f0;
%for i=1:cnt
%    k=constant_point(i);
%    q(2*i-1)=p(k,1);
%    q(2*i)=p(k,2);
%end

u=(inv_A2_B2*q')+(inv_A2*(-f0));

% update the cordinates____________________
finalp=zeros(top,2);
for i=1:cnt
    k=constant_point(i);
    finalp(k,1)=q(2*i-1);
    finalp(k,2)=q(2*i);
end
index=0;
for i=1:top
    if ~finalp(sigma2(i),1)
         index=index+1;
         finalp(sigma2(i),1)=u(2*index-1);
         finalp(sigma2(i),2)=u(2*index);
    end
end
% refresh the screen:_____________________
figure(4);

im=zeros(mm+100,nn+100);
for r=1:cnt
    k=constant_point(r);
    c=finalp(k,1);
    d=finalp(k,2);
    im(c-2:c+2,d-2:d+2)=255*ones(5);
end
imshow(im);
hold on;
triplot(tri,finalp(:,2),finalp(:,1),'red');
hold off;
p=finalp;
end;