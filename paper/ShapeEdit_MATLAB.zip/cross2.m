function w=cross2(u,v)
w=-(u(1)*v(2)-u(2)*v(1));
