function bnd2=transfer_to_origin_coordinate(bnd)
max_X=max(bnd(:,1));
max_Y=max(bnd(:,2));
min_X=min(bnd(:,1));
min_Y=min(bnd(:,2));
center=[(abs(max_X)+abs(min_X))/2 (abs(max_Y)+abs(min_Y))/2];

bnd(:,3)=1;
bnd=bnd*[1 0; 0 1; -center(1) -center(2)];
bnd2=bnd(:,1:2);
