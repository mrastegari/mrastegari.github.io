function shape_edit_moving(model,new_points)
constant_point=model{1};
p=model{2};
cnt=model{3};
B_inv_A=model{4};
top=model{5};
sigma=model{6};
mm=model{7};
nn=model{8};
tri=model{9};
p0=model{10};
inv_A2_B2=model{11};
inv_A2=model{12};
sigma2=model{13};
delta_center=model{14};

p(:,1)=p(:,1)+delta_center(1);
p(:,2)=p(:,2)+delta_center(2);
new_points(:,1)=new_points(:,1)+delta_center(1);
new_points(:,2)=new_points(:,2)+delta_center(2);
display_flag=0;


% while (1)
% %moving some constraint points:
% [j i t]=ginput(1);
% if t==3
%     break;
% end
% for r=1:cnt
%     k=constant_point(r);
%     if (abs(i-p(k,1))<=5)&(abs(j-p(k,2))<=5)
%         index=k;
%         
%     end
% end
% [j i t]=ginput(1);

% p(index,1)=round(i); p(index,2)=round(j);
p(constant_point,1)=round(new_points(:,1)); 
p(constant_point,2)=round(new_points(:,2));

% making the submatrixes______________________

for i=1:cnt
    k=constant_point(i);
    q(2*i-1)=p(k,1);
    q(2*i)=p(k,2);
end

u=-q*B_inv_A;%*(B*q');
% update the cordinates____________________
newp=zeros(top,2);
for i=1:cnt
    k=constant_point(i);
    newp(k,1)=q(2*i-1);
    newp(k,2)=q(2*i);
end
index=0;
for i=1:top
    if ~newp(sigma(i),1)
         index=index+1;
         newp(sigma(i),1)=u(2*index-1);
         newp(sigma(i),2)=u(2*index);
    end
end
% refresh the screen:_____________________
figure(2);
im=zeros(mm+100,nn+100);



for r=1:cnt
    k=constant_point(r);
    c=newp(k,1);
    d=newp(k,2);
    im(c-2:c+2,d-2:d+2)=255*ones(5);
end
if display_flag==1
  imshow(im);
  hold on;
  triplot(tri,newp(:,2),newp(:,1),'red');
  hold off;
end
%_________________________________________
%____Stage II_____________________________
m=length(tri(:,1));
for k=1:m
    r=tri(k,1);    s=tri(k,2);    z=tri(k,3);
    v=[p0(r,1), p0(r,2), p0(s,1), p0(s,2), p0(z,1), p0(z,2)];
    u=[newp(r,1), newp(r,2), newp(s,1), newp(s,2), newp(z,1), newp(z,2)];
    %AA=[p(r,1) p(r,2); p(s,1) p(s,2)];
    %BB=[newp(r,1) newp(r,2) ; newp(s,1) newp(s,2)];
    %=======================my work===================
  T1=[v(1) v(2); v(3) v(4); v(5) v(6)];
  T2=[u(1) u(2); u(3) u(4); u(5) u(6)];
  M1=[sum(T1(:,1)) sum(T1(:,2))]/3;
  M2=[sum(T2(:,1)) sum(T2(:,2))]/3;
  TM1=T1([1 2 3],:)-[M1;M1;M1];
  TM2=T2([1 2 3],:)-[M2;M2;M2];
  aff=(TM2'+eps)*pinv(TM1'+eps);
   [Ra D Rb]=svd(aff);
    R=Ra*Rb';
    %tet1=abs(acos(R(1,1))); tet2=abs(asin(R(1,2))); tet3=abs(asin(-R(2,1))); tet4=abs(acos(R(2,2)));
    %tet=(tet1+tet2+tet3+tet4)/4;
    %R=[cos(tet) -sin(tet);sin(tet) cos(tet)];
    TM1fitted=(R*TM1')';
   
    T1fitted=TM1fitted([1 2 3],:)+[M2;M2;M2];
    w=[];
    w(1)=T1fitted(1,1); w(2)=T1fitted(1,2);
    w(3)=T1fitted(2,1); w(4)=T1fitted(2,2);
    w(5)=T1fitted(3,1); w(6)=T1fitted(3,2);
  
  

    % Emin=Inf;
  % Wmin=[];
  % for i=1:3
  %  T1=[v(1) v(2); v(3) v(4); v(5) v(6)];
  % T1(:,1)=circshift(T1(:,1),i);
  % T1(:,2)=circshift(T1(:,2),i);
   %  T2=[u(1) u(2); u(3) u(4); u(5) u(6)];
   % M1=[sum(T1(:,1)) sum(T1(:,2))]/3;
   % M2=[sum(T2(:,1)) sum(T2(:,2))]/3;
   % TM1=T1([1 2 3],:)-[M1;M1;M1];
   % TM2=T2([1 2 3],:)-[M2;M2;M2];
   % %%===TM2'=aff*TM1'
   % aff=TM2'*pinv(TM1');
   % [Ra D Rb]=svd(aff);
   % R=Ra*Rb;
   % tet1=acos(R(1,1)); tet2=asin(R(1,2)); tet3=asin(-R(2,1)); tet4=acos(R(2,2));
   % tet=(tet1+tet2+tet3+tet4)/4;
   % R=[cos(tet) sin(tet);-sin(tet) cos(tet)];
   % TM1fitted=(R*TM1')';
   % E=norm(TM1fitted-TM2);
   % T1fitted=TM1fitted([1 2 3],:)+[M2;M2;M2];
   % w=[];
   % w(1)=T1fitted(1,1); w(2)=T1fitted(1,2);
   % w(3)=T1fitted(2,1); w(4)=T1fitted(2,2);
   % w(5)=T1fitted(3,1); w(6)=T1fitted(3,2);
   % if E<Emin 
   %     Emin=E;
   %     Wmin=w;
   % end
   %end
  %w=Wmin;
    %%=====================end my work==========
    
  %  scale=sqrt((v(1)-v(3))^2+(v(2)-v(4))^2)/sqrt((u(1)-u(3))^2+(u(2)-u(4))^2);%norm(AA)/norm(BB);
  %  M=[newp(r,1)+newp(s,1)+newp(z,1) newp(r,2)+newp(s,2)+newp(z,2)]/3;
  %  U=zeros(1,6);
    %w=stageII(v,u);
  %  U([1 3 5])=u([1 3 5])-M(1);
  %  U([2 4 6])=u([2 4 6])-M(2);
  %  U=U*scale;
  %  w([1 3 5])=U([1 3 5])+M(1);
  %  w([2 4 6])=U([2 4 6])+M(2);
    
    
    
    
    newtri(k,1)=3*k-2;   newtri(k,2)=3*k-1;    newtri(k,3)= 3*k;
    newpp(3*k-2,1)=w(1);newpp(3*k-2,2)=w(2);
    newpp(3*k-1,1)=w(3);newpp(3*k-1,2)=w(4);
   newpp(3*k,1)=w(5);newpp(3*k,2)=w(6);
end
%how to save these w.s??   ...ok!
% refresh the screen:_____________________
if display_flag==1
  figure(3);
  im=zeros(mm+100,nn+100);
  for r=1:cnt
       k=constant_point(r);
       c=newp(k,1);
       d=newp(k,2);
       im(c-2:c+2,d-2:d+2)=255*ones(5);
  end
  imshow(im);
  hold on;
  triplot(newtri,newpp(:,2),newpp(:,1),'blue');
  triplot(tri,newp(:,2),newp(:,1),'red');
  hold off;
end



%_________________________________________
%____Stage III_____________________________
%%%===== stageIII=====================================

f=zeros(2*top,1); %?

for k=1:m
    for l=1:3
        r=tri(k,l); s=tri(k,mod(l,3)+1); z=tri(k,mod(l+1,3)+1);
        
        ww=[newpp(3*k-2+mod(l,3),1)-newpp(3*k-3+l,1) ; newpp(3*k-2+mod(l,3),2)-newpp(3*k-3+l,2)];
        f(2*r-1)=f(2*r-1)+2*ww(1); f(2*r)=f(2*r)+2*ww(2);
        f(2*s-1)=f(2*s-1)-2*ww(1); f(2*s)=f(2*s)-2*ww(2);
    end
end
%__________________________________________

for i=1:cnt        
    index1=2*constant_point(i)-1;
    index2=2*top-2*cnt+2*i-1;
    
    
    temp=f(index1); f(index1)=f(index2); f(index2)=temp;
    
    index1=index1+1; index2=index2+1;
    
    temp=f(index1); f(index1)=f(index2); f(index2)=temp;
    
    
end      



% making the submatrixes______________________

f0=f(1:2*top-2*cnt);
 %C=f0;
%for i=1:cnt
%    k=constant_point(i);
%    q(2*i-1)=p(k,1);
%    q(2*i)=p(k,2);
%end

u=(inv_A2_B2*q')+(inv_A2*(-f0));

% update the cordinates____________________
finalp=zeros(top,2);
for i=1:cnt
    k=constant_point(i);
    finalp(k,1)=q(2*i-1);
    finalp(k,2)=q(2*i);
end
index=0;
for i=1:top
    if ~finalp(sigma2(i),1)
         index=index+1;
         finalp(sigma2(i),1)=u(2*index-1);
         finalp(sigma2(i),2)=u(2*index);
    end
end
% refresh the screen:_____________________
figure(4);

im=zeros(mm+100,nn+100);
for r=1:cnt
    k=constant_point(r);
    c=finalp(k,1);
    d=finalp(k,2);
    im(c-2:c+2,d-2:d+2)=255*ones(5);
end
imshow(im);
hold on;
triplot(tri,finalp(:,2),finalp(:,1),'red');
hold off;
p=finalp;
%end;