function Z=deforming_by_tps(cx,cy,X,n_good,X3b);

  % calculate affine cost
  
  A=[cx(n_good+2:n_good+3,:) cy(n_good+2:n_good+3,:)];
   s=svd(A);
   aff_cost=log(s(1)/s(2));
   
  
   
   % warp each coordinate
   fx_aff=cx(n_good+1:n_good+3)'*[ones(1,length(X(:,1))); X'];
   d2=max(dist2(X3b,X),0);
   U=d2.*log(d2+eps);
   fx_wrp=cx(1:n_good)'*U;
   fx=fx_aff+fx_wrp;
   fy_aff=cy(n_good+1:n_good+3)'*[ones(1,length(X(:,1))); X'];
   fy_wrp=cy(1:n_good)'*U;
   fy=fy_aff+fy_wrp;

   Z=[fx; fy]';