function [cx,cy,n_good,X3b,key_points]=tps_computing(x3,y3,key_points)
% Shape Context Demo #1
% match two pointsets from Chui & Rangarajan

% uncomment out one of these commands to load in some shape data
%load save_fish_def_3_1.mat
%load save_fish_noise_3_2.mat
%load save_fish_outlier_3_2.mat
%load frog.mat;
%X=x1;
%Y=y2;

%addpath('d:\MATLAB6p5p1\work\mymotion');
%bnd=mkboundary(rgb2gray(imread('c:\man1.bmp')));
%bnd=dec_point3(bnd',150)';
%bnd=mkboundary(rgb2gray(imread('c:\man2.bmp')));
%bnd=dec_point3(bnd',150)';
%x3=bnd;
    %bnd2=bnd*[cos(pi) sin(pi);-sin(pi) cos(pi)];
%y3=bnd2;

%x3=[1:100;-(1:100)]';
%y3=[1:100;(1:100)]';

X=x3;x1=x3;
Y=y3;y2a=y3;y2=y3;

display_flag=0;
mean_dist_global=[]; % use [] to estimate scale from the data
nbins_theta=8;
nbins_r=3;
nsamp1=size(X,1);
nsamp2=size(Y,1);
ndum1=0;
ndum2=0;
if nsamp2>nsamp1
   % (as is the case in the outlier test)
   ndum1=ndum1+(nsamp2-nsamp1);
end
eps_dum=0.15;
r_inner=1/8;
r_outer=2;
n_iter=5;
r=1; % annealing rate
beta_init=1;  % initial regularization parameter (normalized)

 
if display_flag
    [x,y]=meshgrid(linspace(1,600,18),linspace(1,600,36));
    x=x(:);y=y(:);M=length(x);
 end

if display_flag
   figure(1)
   plot(x1(:,1),x1(:,2),'b+',y2a(:,1),y2a(:,2),'ro')
   title(['original pointsets (nsamp1=' int2str(nsamp1) ', nsamp2=' ...
       int2str(nsamp2) ')'])
   if 0
      h1=text(x1(:,1),x1(:,2),int2str((1:nsamp1)'));
      h2=text(y2a(:,1),y2a(:,2),int2str((1:nsamp2)'));  
      set(h2,'fontangle','italic');
   end
   drawnow
end
tps_iter_match_1
