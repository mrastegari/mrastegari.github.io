function tracked_points=tracking_ky_points()
addpath('E:\MATLAB6p5p1\work\mymotion\shap_edit\sc_demo');
addpath('E:\MATLAB6p5p1\work\mymotion');
addpath('');

I=imread('c:\tpink.bmp');
bnd=mkboundary((1-I));
bnd2=dec_point3(bnd',120)';
bnd2=transfer_to_origin_coordinate(bnd2);
model=shape_edit_registering(bnd2);
key_points=model{2}(model{1},:);


tps{1}.key_points=key_points;
for i=1:(1169-1115)
    cnt1=mkcontour(rgb2gray(imread(strcat('c:\pink\',int2str(1114+i),'.bmp'))))';
    cnt2=mkcontour(rgb2gray(imread(strcat('c:\pink\',int2str(1114+i+1),'.bmp'))))';
    cnt1=dec_point3(cnt1',120)';
    cnt2=dec_point3(cnt2',120)';
    cnt1=transfer_to_origin_coordinate(cnt1);
    cnt2=transfer_to_origin_coordinate(cnt2);
    aff1=affine_perm3(bnd2',cnt1');
    aff2=affine_perm3(bnd2',cnt2');
    cnt1=(aff1.affperm)';
    cnt2=(aff2.affperm)';
    if (i>1) 
      [tps{i}.cx tps{i}.cy tps{i}.n_good tps{i}.X3b tps{i}.key_points]=tps_computing(cnt1,cnt2,tps{i-1}.key_points);
    else
      [tps{i}.cx tps{i}.cy tps{i}.n_good tps{i}.X3b tps{i}.key_points]=tps_computing(cnt1,cnt2,tps{i}.key_points);   
    end
end
close all;
save('pinktrack.mat','tps');



for i=1:(1169-1115)
    
    shape_edit_moving(model,tps{i}.key_points);
    pause(0.2);
end