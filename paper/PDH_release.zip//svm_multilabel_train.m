function model=svm_multilabel_train(train_data,label_data,C)
%%%
%%% train_data ====>MxN (M:dim, N:#samples)
%%% label_data ====>NxK (K: # classifiers)

[m_tr n_tr]=size(train_data);
[m_l n_l]=size(label_data);

tr_data=sparse(double(train_data));
for i=1:n_l
    disp(['split#: ' num2str(i)])
    tr_label=double(2*label_data(:,i)-1);
    Np=sum(tr_label==1);
    Nn=sum(tr_label~=1);
    opt = ['-q -B 1 -c ' num2str(C) ' -s 2 -w-1 ' num2str((1/Nn)) ' -w1 ' num2str(1/Np)];
    svmmodel=train(tr_label,tr_data,opt,'col');
    model.w(i,:)=(svmmodel.Label(1)).*(svmmodel.w);
end
