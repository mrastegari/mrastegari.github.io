function model=PDH_train(Image_data,Text_data,Param)



if nargin<3
    Param='nbits=32; niter=4';
end
eval(Param);

%% learn binary code for Image Data
    ITQ_model_img=ITQ_unsup_train(Image_data',nbits,100);
    B_Image_data=ITQ_apply(Image_data',ITQ_model_img);

%% learn binary code for Text Data
    ITQ_model_txt=ITQ_unsup_train(Text_data',nbits,100);
    B_Text_data=ITQ_apply(Text_data',ITQ_model_txt);
    
    

%% learn joint binary code
img_binary=B_Image_data'>0;
txt_binary=B_Text_data'>0;
Error(1)=mean(sum(abs(img_binary-txt_binary)))
for i=1:niter
    disp(['iteration :' num2str(i)])
    txt_model=svm_multilabel_train(Text_data,img_binary',10);
    txt_binary=svm_multilabel_predict(Text_data,txt_model)>0;
    %txt_binary=eigen_dec(double(txt_binary)); %%% we figured out without eigen decomposition the codes are better.
    
    img_model=svm_multilabel_train(Image_data,txt_binary',10);
    img_binary=svm_multilabel_predict(Image_data,img_model)>0;
    
    
    
    Error(i+1)=mean(sum(abs(img_binary-txt_binary)))
end

%% output model
model.img_model=img_model;
model.txt_model=txt_model;
model.err=Error;

