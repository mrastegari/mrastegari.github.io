function model=SH_train(data,nbits)
SHparam.nbits = nbits;
model=trainSH(data,SHparam);