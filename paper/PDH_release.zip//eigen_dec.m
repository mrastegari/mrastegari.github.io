function B_new=eigen_dec(B)
[nbits n]=size(B);
S=(B'*B);
D=diag(sum(S,2));
[ev dv]=eig(D-S);
[~, s_idx]=sort(diag(dv));
B_new=ev(:,s_idx(1:nbits))'>0;



